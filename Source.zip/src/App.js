import {
  Container,
  CssBaseline,
  Paper,
  ThemeProvider,
} from '@material-ui/core';
import React, { useContext } from 'react';
import { Store } from './Store';
import {BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ChooseScreen from './screens/ChooseScreen';
import HomeScreen from './screens/HomeScreen';
import OrderScreen from './screens/OrderScreen';
import QueueScreen from './screens/QueueScreen';
import { createTheme } from '@material-ui/core/styles';
import ReviewScreen from './screens/ReviewScreen';
import PaymentScreen from './screens/PaymentScreen';
import AdminScreen from './screens/AdminScreen';
import SelectPaymentScreen from './screens/SelectPaymentScreen';
import CompleteOrderScreen from './screens/CompleteOrderScreen';
import { Helmet } from 'react-helmet';

const theme = createTheme({
  typography: {
    h1: { fontWeight: 'bold' },
    h2: {
      fontSize: '2rem',
      color: 'black',
    },
    h3: {
      fontSize: '1.8rem',
      fontWeight: 'bold',
      color: 'white',
    },
  },
  palette: {
    primary: { main: '#ff1744' },
    secondary: {
      main: '#118e16',
      contrastText: '#ffffff',
    },
  },
});
function App() {
  const { state } = useContext(Store);

  return (
    <Router>
      <Helmet>
        <title>Self-Order Kiosk</title>
      </Helmet>

    
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Container maxWidth={state.widthScreen ? 'lg' : 'sm'}>
          <Paper>
            <Routes>
              <Route path="/" element={<HomeScreen />} />
              <Route path="/adminnetwork69" element={<AdminScreen />} />
              <Route path="/queue" element={<QueueScreen />} />
              <Route path="/choose" element={<ChooseScreen />} />
              <Route path="/order" element={<OrderScreen />} />
              <Route path="/review" element={<ReviewScreen />} />
              <Route path="/select-payment" element={<SelectPaymentScreen />} />
              <Route path="/payment" element={<PaymentScreen />} />
              <Route path="/complete" element={<CompleteOrderScreen />} />
            </Routes>
          </Paper>
        </Container>
      </ThemeProvider>

    </Router>
  );
}
export default App;
